package com.bookswagon.pagefactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class BaseClass {

public static WebDriver driver ;
	
	public static WebDriver getDriver()
	{
		return driver;
	}

	@Before()
	public static void getBrowser()
	{
	    driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("https://www.bookswagon.com/");	
	}
	
	@After()
	public static void teardown() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.close();
	}
	
	
}

