package com.bookswagon.pagefactory;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
public class Login_Page {
	
	WebDriver driver;

	@FindBy(xpath = "//span[@id='ctl00_lblUser']")
	WebElement myaccount;

	@FindBy(xpath = "//input[@id='ctl00_phBody_SignIn_txtEmail']")
	WebElement mobileNumber;

	@FindBy(xpath = "//input[@id='ctl00_phBody_SignIn_txtPassword']")
	WebElement password;

	@FindBy(xpath = "//a[@id='ctl00_phBody_SignIn_btnLogin']")
	WebElement loginButton;
	
	@FindBy(xpath="//label[@id='ctl00_phBody_SignIn_lblemailmsg']")
    WebElement wrongUsernameErrorMessage;

    @FindBy(xpath="//label[@id='ctl00_phBody_SignIn_lblmsg']")
    WebElement wrongPasswordErrorMessage;
	
	
	public Login_Page (WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}


	public void MyAccount() {
	myaccount.click();

	}

	public void EntermobileNumber(String mobileNumber1) {
		mobileNumber.sendKeys(mobileNumber1);
	}

	public void EnterPassword(String userPassword) {
		password.sendKeys(userPassword);
	}

	public void ClickOnLoginButton() {
		loginButton.click();
	}
	public void clickonemailtext() {
		mobileNumber.click();
	}

	public String getWrongUsernameErrorMessage() {
        return wrongUsernameErrorMessage.getText();
    }

    public String getWrongPasswordErrorMessage() {
        return wrongPasswordErrorMessage.getText();
    }
    
    public void captureScreenshot(String fileName) {
        try {
            // Cast WebDriver to TakesScreenshot
            TakesScreenshot screenshot = (TakesScreenshot) driver;

            // Capture the screenshot as a file
            File sourceFile = screenshot.getScreenshotAs(OutputType.FILE);

            // Specify the destination path
            File destinationFile = new File("C:\\Users\\Swetha\\eclipse-workspace\\RLL_Bookswagon\\RLL_Bookswagon_FinalProject\\LoginScreenshot\\" + fileName + ".png");

            // Copy the file to the destination path
            FileUtils.copyFile(sourceFile, destinationFile);
            
            System.out.println("Screenshot captured: " + destinationFile.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error while capturing screenshot: " + e.getMessage());
        }
    }
	public void navigateToURL(String string) {
		// TODO Auto-generated method stub
		
	}
}
