package com.bookswagon.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Awardwinnerpage {

	WebDriver driver;

	@FindBy(xpath = "//span[@id='ctl00_lblUser']")
	WebElement myaccount;

	@FindBy(xpath = "//input[@id='ctl00_phBody_SignIn_txtEmail']")
	WebElement email;

	@FindBy(xpath = "//input[@id='ctl00_phBody_SignIn_txtPassword']")
	WebElement password;

	@FindBy(xpath = "//a[@id='ctl00_phBody_SignIn_btnLogin']")
	WebElement loginButton;

	@FindBy(xpath = "//a[text()='Award Winners']")
	WebElement AwardWinner;

	@FindBy(xpath = "//select[@id='ddlSort']")
	WebElement SortYourListByRelevance;

	@FindBy(xpath = "//select[@id='ddlSort']")
	WebElement SortYourListByPriceLowToHigh;

	@FindBy(xpath = "//select[@id='ddlSort']")
	WebElement SortYourListByPriceHighToLow;

	@FindBy(xpath = "//select[@id='ddlSort']")
	WebElement SortYourListByDiscount;
	
	@FindBy(xpath = "//img[@class='card-img-top bklazy']")
	WebElement SelectTheProduct;
	
	@FindBy(xpath = "//a[text()='Buy Now']")
	WebElement BuyProduct;
	
	@FindBy(xpath = "//a[@class='btn themeborder themecolor d-block mb-2']")
	WebElement Wishlist;
	

	public Awardwinnerpage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void navigateToURL(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(2000);
	}

	public void MyAccount() throws InterruptedException {
		myaccount.click();
		Thread.sleep(2000);

	}

	public void EnterEmail(String userEmail) throws InterruptedException {
		email.sendKeys(userEmail);
		Thread.sleep(2000);
	}

	public void EnterPassword(String userPassword) throws InterruptedException {
		password.sendKeys(userPassword);
		Thread.sleep(2000);
	}

	public void ClickOnLoginButton() throws InterruptedException {
		loginButton.click();
		Thread.sleep(2000);
	}

	public void Award_Winner() throws InterruptedException {
		AwardWinner.click();
		Thread.sleep(2000);
	}


	public void SortYourList_By_Relevance() throws InterruptedException {
		SortYourListByRelevance.click();
		Select dd = new Select(SortYourListByRelevance);
		dd.selectByVisibleText("Relevance");
		Thread.sleep(2000);
	}

	public void Sort_Your_List_By_Price_Low_To_High() throws InterruptedException {
		SortYourListByPriceLowToHigh.click();
		Select dd = new Select(SortYourListByPriceLowToHigh);
		dd.selectByVisibleText("Price - Low to High");
		Thread.sleep(2000);
	}

	public void Sort_Your_List_By_Price_High_To_Low() throws InterruptedException {
		SortYourListByPriceHighToLow.click();
		Select dd = new Select(SortYourListByPriceHighToLow);
		dd.selectByVisibleText("Price - High to Low");
		Thread.sleep(2000);
	}

	public void Sort_Your_List_By_Discount() throws InterruptedException {
		SortYourListByDiscount.click();
		Select dd = new Select(SortYourListByDiscount);
		dd.selectByVisibleText("Discount");	
		Thread.sleep(2000);
		}
	public void Select_The_Product() throws InterruptedException {
		SelectTheProduct.click();
		Thread.sleep(2000);
	}
	public void By_product() throws InterruptedException {
		BuyProduct.click();
		Thread.sleep(2000);
    }
	public void Add_wishlist() throws InterruptedException {
		Wishlist.click();
		Thread.sleep(2000);
    }

}