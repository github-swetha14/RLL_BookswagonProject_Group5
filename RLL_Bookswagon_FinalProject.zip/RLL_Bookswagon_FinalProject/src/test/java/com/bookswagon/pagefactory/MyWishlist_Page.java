package com.bookswagon.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class MyWishlist_Page {

	WebDriver driver;

	@FindBy(xpath = "//span[@id='ctl00_lblUser']")
	WebElement myaccount;

	@FindBy(xpath = "//input[@id='ctl00_phBody_SignIn_txtEmail']")
	WebElement phone;

	@FindBy(xpath = "//input[@id='ctl00_phBody_SignIn_txtPassword']")
	WebElement password;

	@FindBy(xpath = "//a[@id='ctl00_phBody_SignIn_btnLogin']")
	WebElement loginButton;
	
	@FindBy(xpath = "//a[@href='wishlist.aspx']")
	WebElement MyWishlist;

	@FindBy(xpath = "//input[@id='inputbar']")
	WebElement SearchBar;

	@FindBy(xpath = "//input[@id='btnTopSearch']")
	WebElement SearchIcon;

	@FindBy(xpath = "//*[@id=\"listSearchResult\"]/div[4]/div[4]/div[5]/input[2]")
	WebElement AddtoWishist;
	
	@FindBy(xpath = "//*[@id=\"listSearchResult\"]/div[5]/div[4]/div[5]/input[2]")
	WebElement AddtoWishist2;

	@FindBy(id= "ctl00_lblUser")
	WebElement DemoUser;
	
	@FindBy(id="ctl00_phBody_WishList_lvWishList_ctrl0_ImageButton1")
	WebElement RemoveOption;
	
	@FindBy(id= "ctl00_phBody_WishList_lvWishList_chkAll")
	WebElement Selectall_checkbox;
	
	@FindBy(id= "ctl00_phBody_WishList_lvWishList_imgDelete")
	WebElement RemoveButton;
	
	public MyWishlist_Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void navigateToURL(String url) {
		driver.get(url);
	}

	public void MyAccount() {
		myaccount.click();

	}

	public void EnterPhone(String userPhone) {
		phone.sendKeys(userPhone);
	}

	public void EnterPassword(String userPassword) {
		password.sendKeys(userPassword);
	}

	public void ClickOnLoginButton() {
		loginButton.click();
	}
	
	public void click_MyWishlist() {
		MyWishlist.click();
	}
	
	public void type_product(String samplebook) {
		SearchBar.sendKeys(samplebook);	
		SearchIcon.click();
    }
	
	public void click_AddWishlist() {
	AddtoWishist.click();
	}
	
	public void click_AddWishlist2() {
    AddtoWishist2.click();
	}
	
	public void click_demouser() {
	DemoUser.click();
	}
	
	public void click_Remove() {
	RemoveOption.click();
	}
	
	public void click_selectall() {
	Selectall_checkbox.click();
	}
	
	public void click_removebutton() {
	RemoveButton.click();
	}
	
}
