package com.bookswagon.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Add_Address_Page {

	WebDriver driver;

	@FindBy(xpath = "//span[@id='ctl00_lblUser']")
	WebElement myaccount;

	@FindBy(xpath = "//input[@id='ctl00_phBody_SignIn_txtEmail']")
	WebElement phone;

	@FindBy(xpath = "//input[@id='ctl00_phBody_SignIn_txtPassword']")
	WebElement password;

	@FindBy(xpath = "//a[@id='ctl00_phBody_SignIn_btnLogin']")
	WebElement loginButton;
	

	@FindBy(xpath = "//*[@id=\"site-wrapper\"]/div/div/div/div/div/div[5]/div/a")
	WebElement My_Address;
	
	@FindBy(xpath = "//*[@id=\"site-wrapper\"]/div/div/div/div/div/div[2]/div/a")
	WebElement Add_Address;
	
	@FindBy(id = "ctl00_phBody_ShippingAddress_txtRecipientName")
	WebElement FullName;
	
	@FindBy(id = "ctl00_phBody_ShippingAddress_txtAddress")
	WebElement StreetAddress;
	
	@FindBy(xpath = "//select[@id='ctl00_phBody_ShippingAddress_ddlCountry']")
    WebElement country;
	
	@FindBy(xpath = "(//option[contains(text(),'India')])[1]")
    WebElement selectCountrydrop;


    @FindBy(xpath = "//select[@id='ctl00_phBody_ShippingAddress_ddlState']")
    WebElement state;

    @FindBy(xpath = "(//option[contains(text(),'Tamil Nadu')])[1]")
    WebElement selectStatedrop;

    @FindBy(xpath = "//select[@id='ctl00_phBody_ShippingAddress_ddlCities']")
    WebElement city;

    @FindBy(xpath = "(//option[contains(text(),'Chennai')])[1]")
    WebElement selectCitydrop;

    @FindBy(xpath = "//input[@id='ctl00_phBody_ShippingAddress_txtPincode']")
    WebElement pin_code;

    @FindBy(xpath = "//input[@id='ctl00_phBody_ShippingAddress_txtMobile']")
    WebElement mobile;

    @FindBy(xpath = "//a[@id='ctl00_phBody_ShippingAddress_imgSubmit']")
    WebElement save;
    

    public Add_Address_Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void navigateToURL(String url) {
		driver.get(url);
	}

	public void MyAccount() {
		myaccount.click();

	}

	public void EnterPhone(String userPhone) {
		phone.sendKeys(userPhone);
	}

	public void EnterPassword(String userPassword) {
		password.sendKeys(userPassword);
	}

	public void ClickOnLoginButton() {
		loginButton.click();
	}

	public void click_MyAddress() {
		My_Address.click();
	}
	
	
	public void click_AddAddress() {
		Add_Address.click();
	}
	
	public void Enterfullname(String name ) {
		FullName.click();
		FullName.sendKeys(name);
    }
	
	public void EnterStreetAddress(String Address ) {
		StreetAddress.click();
		StreetAddress.sendKeys(Address);
    }
	
	public void EnterCountry() {
		country.click();
		selectCountrydrop.click();
    }
	
	public void EnterState()  {
		state.click();
		selectStatedrop.click();
    }
	
	public void EnterCity() throws InterruptedException {
		Thread.sleep(2000);
		city.click();
		Thread.sleep(2000);
		selectCitydrop.click();
    }
	

	public void EnterPinCode(String Pincode ) {
		pin_code.click();
		pin_code.sendKeys(Pincode);
    }
	
	public void EnterPhone1(String Phone) {
		mobile.click();
		mobile.sendKeys(Phone);
    }
	
	public void ClickUpdate() {
		save.click();
	}
	
}
