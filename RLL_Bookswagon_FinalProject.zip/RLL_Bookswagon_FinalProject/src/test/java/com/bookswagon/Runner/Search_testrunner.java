package com.bookswagon.Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features = { "C:\\Users\\Swetha\\eclipse-workspace\\RLL_Bookswagon\\RLL_Bookswagon_FinalProject\\src\\test\\java\\com\\bookswagon\\features\\search.feature" }, 
                  glue = { "com.bookswagon.stepdefinition" }, 
                  monochrome = true, plugin = {
		          "html:target/cucumber-html-report/cucumber.html"
		           })

public class Search_testrunner extends AbstractTestNGCucumberTests {


}
