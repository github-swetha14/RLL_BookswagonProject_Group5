package com.bookswagon.Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features="C:\\Users\\Swetha\\eclipse-workspace\\RLL_Bookswagon\\RLL_Bookswagon_FinalProject\\src\\test\\java\\com\\bookswagon\\features\\RequestABook.feature",
						
				glue= {"com.bookswagon.stepdefinition","com.bookswagon.pagefactory"},
				dryRun=false,
						plugin={"pretty",
								"html:target/myreport2.html",
								  "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
								  "timeline:test-output-thread/"}
)
public class RequestBook_testrunner extends AbstractTestNGCucumberTests {

	
	
}