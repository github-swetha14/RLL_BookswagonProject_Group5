package com.bookswagon.stepdefinition;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.bookswagon.pagefactory.MyWishlist_Page;
import com.bookswagon.stepdefinition.MyWishlist_Stepdef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyWishlist_Stepdef {

	private static final Logger logger = LogManager.getLogger(MyWishlist_Stepdef.class);
	
	WebDriver driver;
	MyWishlist_Page lp;
	
	@Given("the URL of bookswagon website")
	public void the_url_of_bookswagon_website() {
		logger.info("the URL of bookswagon website");
		// Initialize WebDriver
		driver = new ChromeDriver();

		// Initialize LoginPage with the WebDriver
		lp = new MyWishlist_Page(driver);

		// Navigate to the URL
		lp.navigateToURL("https://www.bookswagon.com/");
		driver.manage().window().maximize();
	}

	@Then("click on myaccount option")
	public void click_on_myaccount_option() {
		logger.info("click on myaccount option");
		lp.MyAccount();
		 String expectedTitle = "Online BookStore India, Buy Books Online, Buy Book Online India - Bookswagon.com";
		  String actualTitle = driver.getTitle();
		  Assert.assertEquals(expectedTitle, actualTitle);
		 // logger.error("Error occured");
	}
	
	@When("the User enters phone no as {string}")
	public void the_user_enters_phone_no_as(String string) {
		logger.info("the User enters phone no as {string}");
		lp.EnterPhone("9840766828");
	}

	@When("the User enters password as {string}")
	public void the_user_enters_password_as(String string) {
		logger.info("the User enters password as {string}");
		lp.EnterPassword("Book@123");
	}

	@When("the User clicked on the login button")
	public void the_user_clicked_on_the_login_button() {
		logger.info("the User clicked on the login button");
		lp.ClickOnLoginButton();
	}
	
	@When("User click on My Wishlist")
	public void user_click_on_my_wishlist() {
		logger.info("User click on My Wishlist");
        lp.click_MyWishlist();
	}

	@When("User search for a book titled {string}")
	public void user_search_for_a_book_titled(String string) {
		logger.info("User search for a book titled {string}");
	    lp.type_product("Travel");
	}

	@When("User click on the Add to Wishlist button")
	public void user_click_on_the_add_to_wishlist_button() throws InterruptedException {
		logger.info("User click on the Add to Wishlist button");
        lp.click_AddWishlist();
        Thread.sleep(1000);
        lp.click_AddWishlist2();
        Thread.sleep(1000);
        lp.click_demouser();
	}

	@Then("User should see the list of books in my wishlist")
	public void user_should_see_the_list_of_books_in_my_wishlist() throws InterruptedException {
		logger.info("User should see the list of books in my wishlist");
		lp.click_demouser();
		Thread.sleep(900);
		lp.click_MyWishlist();
		
	}

	@Then("User can remove a book from my wishlist")
	public void user_can_remove_a_book_from_my_wishlist() throws InterruptedException {
		logger.info("User can remove a book from my wishlist");
		Thread.sleep(2000);
		lp.click_Remove();
	}

	@Then("User should see a message indicating that my wishlist is empty {string}")
	public void user_should_see_a_message_indicating_that_my_wishlist_is_empty(String string) throws InterruptedException {
		logger.info("User should see a message indicating that my wishlist is empty {string}");
		Thread.sleep(2000);
		lp.click_selectall();
		Thread.sleep(3000);
	    lp.click_removebutton();
	  
	    
	}


}